/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import com.mycompany.app.TaskManager;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author RC_Student_lab
 */
public class TaskManagerTask {
     class TaskTest {
        
    @test
    public void testDeveloperArray() {
        TaskManager taskManager = new TaskManager();
        taskManager.populateArrays();
        String[] expectedDevelopers = new String[]{"Mike Smith", "Edward Harrison", "Samantha Paulson", "Glenda Oberholzer"};
        assertEquals(Arrays.toString(expectedDevelopers), Arrays.toString(taskManager.developers));
    }

    @test
    public void testDisplayLongestTaskDuration() {
        TaskManager taskManager = new TaskManager();
        taskManager.populateArrays();
        assertEquals("Glenda Oberholzer - 11", taskManager.displayLongestTaskDuration());
    }

    @test
    public void testSearchTask() {
        TaskManager taskManager = new TaskManager();
        taskManager.populateArrays();
        assertEquals("Create Login - Mike Smith - To Do", taskManager.searchTask("Create Login"));
    }

    @test
    public void testSearchTasksForDeveloper() {
        TaskManager taskManager = new TaskManager();
        taskManager.populateArrays();
        assertEquals("Create Reports - Done", taskManager.searchTasksForDeveloper("Samantha Paulson"));
    }

    @Test
    public void testDeleteTask() {
        TaskManager taskManager = new TaskManager();
        taskManager.populateArrays();
        assertEquals("Entry 'Create Reports' successfully deleted", taskManager.deleteTask("Create Reports"));
    }

    @Test
    public void testDisplayReport() {
        TaskManager taskManager = new TaskManager();
        taskManager.populateArrays();
        String expectedReport = "Task Name: Create Login\n" +
                "Developer: Mike Smith\n" +
                "Duration: 5\n" +
                "Status: To Do\n\n" +
                "Task Name: Create Add Features\n" +
                "Developer: Edward Harrison\n" +
                "Duration: 8\n" +
                "Status: Doing\n\n" +
                "Task Name: Create Reports\n" +
                "Developer: Samantha Paulson\n" +
                "Duration: 2\n" +
                "Status: Done\n\n" +
                "Task Name: Add Arrays\n" +
                "Developer: Glenda Oberholzer\n" +
                "Duration: 11\n" +
                "Status: To Do";
        
    }
}


    }




    
    
    
   