/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.app;

import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author RC_Student_lab
 */
 class App {
 public static void main(String[] args){
    class Login {
    private String username;
    private String password;
    private String firstName;
    private String lastName;

    public String getUsername() {
        return username;
    }
// setting user name 
    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
//checking user name 
    public boolean checkUserName() {
        return username.length() <= 5 && username.contains("_");
    }

    public boolean checkPasswordComplexity() {
        return password.length() >= 8 && password.matches(".[A-Z].") && password.matches(".\\d.") && password.matches(".[@#$%^&+=].");
    }
//register 
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.";
        } else if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.";
        } else {
            return "User successfully registered";
        }
    }
//Login
    public boolean loginUser(String enteredUsername, String enteredPassword) {
        return username.equals(enteredUsername) && password.equals(enteredPassword);
    }
//returning login status
    public String returnLoginStatus() {
        if (loginUser(username, password)) {
            return "Welcome " + firstName + " " + lastName + ", it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again";
    }
    }}}
//PART 2 POE
 class Task {
    private String taskName;
    private int taskNumber;
    private String taskDescription;
    private String developerDetails;
    private int taskDuration;
    private String taskID;
    private String taskStatus;
 
    public Task(String taskName, int taskNumber, String taskDescription, String developerDetails, int taskDuration, String taskStatus) {
        this.taskName = taskName;
        this.taskNumber = taskNumber;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskStatus = taskStatus;
        this.taskID = createTaskID();
    }

    public boolean checkTaskDescription() {
        return taskDescription.length() <= 50;
    }

    public String createTaskID() {
        String firstTwoLetters = taskName.substring(0, 2).toUpperCase();
        String lastThreeLetters = developerDetails.substring(developerDetails.length() - 3).toUpperCase();
        return firstTwoLetters + ":" + taskNumber + ":" + lastThreeLetters;
    }

    public String printTaskDetails() {
        return "Task Status: " + taskStatus + "\n" +
               "Developer Details: " + developerDetails + "\n" +
               "Task Number: " + taskNumber + "\n" +
               "Task Name: " + taskName + "\n" +
               "Task Description: " + taskDescription + "\n" +
               "Task ID: " + taskID + "\n" +
               "Task Duration: " + taskDuration + " hours";
    }

    public int getTaskDuration() {
        return taskDuration;
    }

    public void main(String[] args) {
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks: "));
        int totalHours = 0;

        for (int i = 0; i < numTasks; i++) {
            String taskName = JOptionPane.showInputDialog("Enter task name: ");
            String taskDescription = JOptionPane.showInputDialog("Enter task description: ");
            while (taskDescription.length() > 50) {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
                taskDescription = JOptionPane.showInputDialog("Enter task description: ");
            }
            String developerDetails = JOptionPane.showInputDialog("Enter developer details: ");
            int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter task duration: "));
            String taskStatus = getTaskStatus();

            Task task = new Task(taskName, i, taskDescription, developerDetails, taskDuration, taskStatus);
            JOptionPane.showMessageDialog(null, task.printTaskDetails());
            totalHours += task.getTaskDuration();
        }

        JOptionPane.showMessageDialog(null, "Total hours: " + totalHours);
    }
    
    private static String getTaskStatus() {
        String[] options = {"To Do", "Done", "Doing"};
        
        return (String) JOptionPane.showInputDialog(null, "Select task status: ", "Task Status", JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
    }
 
    }}
 
//POE PART3

public class TaskManager {
    static String[] developers = new String[] {};
    static String[] taskNames = new String[] {};
     static int[] taskID = new int[] {};
    static int[] taskDuration = new int[] {};
    static String[] taskStatus = new String[] {};

    public static void main(String[] args) {
        populateArrays();
        displayDoneTasks();
        displayLongestTaskDuration();
        searchTask("Create Login");
        searchTasksForDeveloper("Samantha Paulson");
        deleteTask("Create Reports");
        displayReport();
    }

    public static void populateArrays() {
        developers = new String[]{"Mike Smith", "Edward Harrison", "Samantha Paulson", "Glenda Oberholzer"};
        taskNames = new String[]{"Create Login", "Create Add Features", "Create Reports", "Add Arrays"};
        taskID = new int[]{1, 2, 3, 4};
        taskDuration = new int[]{5, 8, 2, 11};
        taskStatus = new String[]{"To Do", "Doing", "Done", "To Do"};
    }

    public static void displayDoneTasks() {
        for (int i = 0; i < taskNames.length; i++) {
            if (taskStatus[i].equals("Done")) {
                System.out.println(taskNames[i] + " - " + developers[i] + " - " + taskDuration[i]);
            }
        }
    }

    public static void displayLongestTaskDuration() {
        int maxDuration = 0;
        String longestDeveloper = "";
        for (int i = 0; i < taskNames.length; i++) {
            if (taskDuration[i] > maxDuration) {
                maxDuration = taskDuration[i];
                longestDeveloper = developers[i];
            }
        }
        System.out.println(longestDeveloper + " - " + maxDuration);
    }

    public static void searchTask(String taskName) {
        for (int i = 0; i < taskNames.length; i++) {
            if (taskNames[i].equals(taskName)) {
                System.out.println(taskNames[i] + " - " + developers[i] + " - " + taskStatus[i]);
                return;
            }
        }
        System.out.println("Task not found");
    }

    public static void searchTasksForDeveloper(String developerName) {
        for (int i = 0; i < taskNames.length; i++) {
            if (developers[i].equals(developerName)) {
                System.out.println(taskNames[i] + " - " + taskStatus[i]);
            }
        }
    }

    public static void deleteTask(String taskName) {
        for (int i = 0; i < taskNames.length; i++) {
            if (taskNames[i].equals(taskName)) {
                System.out.println("Entry '" + taskName + "' successfully deleted");
                return;
            }
        }
        System.out.println("Task not found");
    }

    public static void displayReport() {
        for (int i = 0; i < taskNames.length; i++) {
            System.out.println("Task Name: " + taskNames[i]);
            System.out.println("Developer: " + developers[i]);
            System.out.println("Duration: " + taskDuration[i]);
            System.out.println("Status: " + taskStatus[i]);
            System.out.println();
        }
    }
}


 